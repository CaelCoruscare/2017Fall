#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define HEAPSIZE 320000

int *heap;
int *book;

void init();
int search(int spot, int size);
void mov(int* point);
int* maloc(int size);
void fre(int *spot);

int main()
{
  init();
  int action;
  int size;
  printf("usage for maloc: 1 size\nusage for fre: 2 locationInBook\nfre should be given odd numbers\n"); 
  scanf("%d %d", &action, &size);

  while(1)
  {
    if (action == 1)
    {
      printf("Here is your pointer: %p\n", maloc (size));
    }
    else
    {
      fre(book + size);
      printf("freed.\n");
    }

    for (int i = 0; i < 16; i++)
      {
        printf("%d\n", book[i]);
      }
    printf("\n\n");
    scanf("%d %d", &action, &size);
    printf("\n");
  }
}

void init()
{
  heap = malloc(HEAPSIZE);
  book = malloc(3200);
  book[0] = book[1] = -1;
}

// return pointer to space, or -1 on failure.
int* maloc (int size)
{
  //search for open space
  int s =  (search(1, size));
  if (s == -1) return (int*) -1;
  return (heap + s);
}

//-1 means end. -2 means open space.
int search (int spot, int size)
{
  if((spot+size) > HEAPSIZE) return -1;
 
  //if -1...
  if (book[spot] == -1)
  {
    book[spot] = 1 + book[spot-1]; //make a note of where the block starts
    book[spot+1] = book[spot] + size - 1; //make a note of where the block ends
    book[spot+2] = -1;
    return book[spot]; //return the start of the memory
  }

  //if -2...
  if (book[spot] == -2)
  {
    //Find the next filled chunk of memory.
    int i = 2;
    while(book[spot+i] == -2)
    {
      i += 2;
    }

    //If there is enough space between these blocks for the new chunk of memory...
    if ((book[spot+i] - book[spot-1]) > size)
    {
      book[spot] = 1 + book[spot-1]; //make a note of where the block starts
      book[spot+1] = book[spot] + size - 1; //make a note of where the block ends
      return spot;
    }
    else return search(spot+i, size); //else resume search at the next filled chunk of memory.
  }

//If there is a space between this one and the next.
  if ((book[spot+2] - book[spot+1]) > size)
  {
    mov(book + spot + 2);
    book[spot+2] = 1 + book[spot+1]; //make a note of where the block starts
    book[spot+3] = book[spot+2] + size - 1; //make a note of where the block ends
    return book[spot+2];
  }

  return search(spot+2, size);
}

void mov(int* point)
{
  int c,k,l;
  for (int i = 0; i < 16 && *point != -1; i += 2)
  {
    l = *(point+i);
    *(point+i) = c;
    c = l;
    l = *(point+i+1);
    *(point+i+1) = k;
    k = l;
  }
}

void fre(int *spot)
{
  *spot = -2;
}
